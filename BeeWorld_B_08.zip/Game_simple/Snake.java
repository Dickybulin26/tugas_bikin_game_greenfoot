import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Snake here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Snake extends Actor
{
    /**
     * Act - do whatever the Snake wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        move(4);
        if(Greenfoot.getRandomNumber(500)<80){
            turn(Greenfoot.getRandomNumber(400 - 75));
        }
        eatBug();
        getImage().scale(90,80);
    }
    
    public void eatBug(){
        if(isTouching(Bug.class)){
            removeTouching(Bug.class);
            getWorld().showText("Game Over!", 400,300);
            Greenfoot.stop();
        }
    }
}
