import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */


public class MyWorld extends World
{
    private GreenfootSound backgroundMusic = new GreenfootSound("Happy Chiptune.mp3");
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 600, 1); 
        prepare();
        backgroundMusic.playLoop();
    }
    
    private void prepare(){
        Bug bug = new Bug();
        addObject(bug,106,178);
        Cherry cherry = new Cherry();
        addObject(cherry,406,182);
        cherry.setLocation(463,189);
        cherry.setLocation(413,534);
        Cherry cherry2 = new Cherry();
        addObject(cherry2,596,99);
        Cherry cherry3 = new Cherry();
        addObject(cherry3,64,369);
        Cherry cherry4 = new Cherry();
        addObject(cherry4,662,289);
        Snake snake = new Snake();
        addObject(snake,423,318);
        snake.setLocation(441,38);
        cherry.setLocation(449,524);
        Snake snake2 = new Snake();
        addObject(snake2,449,524);
    }
}
