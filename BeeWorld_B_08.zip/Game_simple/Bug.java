import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bug here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bug extends Actor
{
    /**
     * Act - do whatever the Bug wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int score = 0;
    public void act()
    {
        mover();
        eatCherry();
    }
    
    public void mover(){
        if (Greenfoot.isKeyDown("left")){
            turn(-5);
        }
        if(Greenfoot.isKeyDown("right")){
            turn(5);
        }
        if (Greenfoot.isKeyDown("up")){
            move(4);
        }
        if (Greenfoot.isKeyDown("down")){
            move(-4);
        }
    }
    
    public void eatCherry(){
        if(isTouching(Cherry.class)){
            removeTouching(Cherry.class);
            score++;
            getWorld().showText("Score: " + score, 100,30);
            Greenfoot.playSound("score.mp3");
        }
        if (score == 4){
            getWorld().showText("You Win!",400,300);
            Greenfoot.stop();
            Greenfoot.playSound("Win.mp3");
        }
    }
}
